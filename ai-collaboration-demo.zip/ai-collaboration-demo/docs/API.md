# API 명세서

Claude AI가 개발한 백엔드 API와 Gemini AI가 개발할 프론트엔드 간의 통신 규격입니다.

## Base URL

```
http://localhost:5000/api
```

## 데이터 형식

모든 API는 JSON 형식으로 데이터를 주고받습니다.

### Todo 객체 구조

```json
{
  "id": 1,
  "title": "할 일 제목",
  "description": "상세 설명 (선택사항)",
  "completed": false,
  "created_at": "2025-06-16T23:45:00.123456",
  "updated_at": "2025-06-16T23:45:00.123456"
}
```

## API 엔드포인트

### 1. 모든 할 일 조회

**GET** `/api/todos`

**응답:**
```json
{
  "success": true,
  "data": [
    {
      "id": 1,
      "title": "첫 번째 할 일",
      "description": "설명",
      "completed": false,
      "created_at": "2025-06-16T23:45:00.123456",
      "updated_at": "2025-06-16T23:45:00.123456"
    }
  ],
  "count": 1
}
```

### 2. 새 할 일 생성

**POST** `/api/todos`

**요청 본문:**
```json
{
  "title": "새로운 할 일",
  "description": "상세 설명 (선택사항)"
}
```

**응답:**
```json
{
  "success": true,
  "data": {
    "id": 2,
    "title": "새로운 할 일",
    "description": "상세 설명",
    "completed": false,
    "created_at": "2025-06-16T23:45:00.123456",
    "updated_at": "2025-06-16T23:45:00.123456"
  }
}
```

### 3. 할 일 수정

**PUT** `/api/todos/{id}`

**요청 본문:**
```json
{
  "title": "수정된 제목",
  "description": "수정된 설명",
  "completed": true
}
```

**응답:**
```json
{
  "success": true,
  "data": {
    "id": 1,
    "title": "수정된 제목",
    "description": "수정된 설명",
    "completed": true,
    "created_at": "2025-06-16T23:45:00.123456",
    "updated_at": "2025-06-16T23:50:00.123456"
  }
}
```

### 4. 할 일 삭제

**DELETE** `/api/todos/{id}`

**응답:**
```json
{
  "success": true,
  "message": "Todo deleted successfully"
}
```

### 5. 서버 상태 확인

**GET** `/api/health`

**응답:**
```json
{
  "success": true,
  "message": "Claude AI Backend is running!",
  "timestamp": "2025-06-16T23:45:00.123456",
  "version": "1.0.0"
}
```

## 에러 응답

모든 에러는 다음 형식으로 반환됩니다:

```json
{
  "success": false,
  "error": "에러 메시지"
}
```

### 일반적인 HTTP 상태 코드

- `200`: 성공
- `201`: 생성 완료
- `400`: 잘못된 요청 (validation 실패)
- `404`: 리소스를 찾을 수 없음
- `500`: 서버 내부 오류

## CORS 설정

프론트엔드와의 연동을 위해 CORS가 활성화되어 있습니다.

## 사용 예시 (JavaScript)

```javascript
// 모든 할 일 가져오기
fetch('http://localhost:5000/api/todos')
  .then(response => response.json())
  .then(data => {
    if (data.success) {
      console.log('할 일 목록:', data.data);
    }
  });

// 새 할 일 추가
fetch('http://localhost:5000/api/todos', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
  },
  body: JSON.stringify({
    title: '새로운 할 일',
    description: '설명'
  })
})
.then(response => response.json())
.then(data => {
  if (data.success) {
    console.log('생성된 할 일:', data.data);
  }
});

// 할 일 수정
fetch('http://localhost:5000/api/todos/1', {
  method: 'PUT',
  headers: {
    'Content-Type': 'application/json',
  },
  body: JSON.stringify({
    completed: true
  })
})
.then(response => response.json())
.then(data => {
  if (data.success) {
    console.log('수정된 할 일:', data.data);
  }
});

// 할 일 삭제
fetch('http://localhost:5000/api/todos/1', {
  method: 'DELETE'
})
.then(response => response.json())
.then(data => {
  if (data.success) {
    console.log('삭제 완료');
  }
});
```

---

**작성자:** Claude AI  
**업데이트:** 2025-06-16  
**버전:** 1.0.0
