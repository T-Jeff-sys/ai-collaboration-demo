# Frontend UI (For Gemini AI)

이 디렉토리는 **Gemini AI**가 개발할 프론트엔드 영역입니다.

## 🎯 개발 목표

Claude AI가 만든 백엔드 API와 연동되는 사용자 친화적인 할 일 관리 인터페이스 개발

## 📋 구현해야 할 기능

### 1. 기본 UI 컴포넌트
- [ ] 할 일 목록 표시
- [ ] 새 할 일 추가 폼
- [ ] 할 일 수정/삭제 버튼
- [ ] 완료 상태 토글

### 2. API 연동
- [ ] GET /api/todos - 할 일 목록 로드
- [ ] POST /api/todos - 새 할 일 생성
- [ ] PUT /api/todos/{id} - 할 일 수정
- [ ] DELETE /api/todos/{id} - 할 일 삭제

### 3. 사용자 경험
- [ ] 반응형 디자인 (모바일/데스크톱)
- [ ] 로딩 상태 표시
- [ ] 에러 처리 및 사용자 피드백
- [ ] 직관적인 인터페이스

## 🛠 기술 스택 제안

- **HTML5**: 구조 마크업
- **CSS3**: 스타일링 (Grid/Flexbox, 애니메이션)
- **JavaScript (ES6+)**: 동적 기능 및 API 통신
- **Fetch API**: 백엔드 연동

## 📡 API 엔드포인트 (Claude 제공)

```javascript
// API Base URL
const API_BASE = 'http://localhost:5000/api';

// 사용 예시
fetch(`${API_BASE}/todos`)
  .then(response => response.json())
  .then(data => console.log(data));
```

## 🎨 디자인 가이드라인

- **모던한 UI**: 깔끔하고 직관적인 디자인
- **컬러 팔레트**: 자유롭게 선택 (Gemini의 창의성 발휘!)
- **타이포그래피**: 가독성 좋은 폰트
- **반응형**: 다양한 화면 크기 지원

## 📂 권장 파일 구조

```
gemini-modules/
├── index.html          # 메인 페이지
├── css/
│   ├── styles.css      # 메인 스타일
│   └── responsive.css  # 반응형 스타일
├── js/
│   ├── app.js         # 메인 애플리케이션 로직
│   ├── api.js         # API 통신 모듈
│   └── ui.js          # UI 컴포넌트 관리
└── assets/            # 이미지, 아이콘 등
```

## 🤖 Claude와의 협업 포인트

1. **API 스펙 확인**: Claude가 제공한 API 문서 참조
2. **데이터 구조 이해**: Todo 객체 형태 확인
3. **에러 처리**: Claude API의 에러 응답 형식 활용
4. **코드 리뷰**: 서로의 코드 검토 및 개선 제안

## 🚀 시작하기

백엔드 서버가 실행중인지 확인한 후 프론트엔드 개발을 시작하세요:

```bash
cd ../claude-modules
python app.py  # 백엔드 서버 실행

# 새 터미널에서
cd ../gemini-modules
# 여기서 HTML 파일을 브라우저로 열어 개발 시작
```

---

**Prepared by Claude AI** 🧠  
**Waiting for Gemini AI's creative magic!** ✨  

*힌트: 사용자가 할 일을 쉽게 추가하고 관리할 수 있는 직관적인 인터페이스를 만들어주세요!*
