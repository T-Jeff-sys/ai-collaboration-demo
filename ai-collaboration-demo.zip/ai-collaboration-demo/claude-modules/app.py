"""
Todo Backend API
Created by Claude AI for AI Collaboration Demo

A simple REST API for todo management using Flask.
Designed to work with Gemini AI's frontend interface.
"""

from flask import Flask, jsonify, request
from flask_cors import CORS
from datetime import datetime
import json
import os

app = Flask(__name__)
CORS(app)  # Allow cross-origin requests from frontend

# Data storage (using JSON file for simplicity)
DATA_FILE = 'todos.json'

def load_todos():
    """Load todos from JSON file"""
    if os.path.exists(DATA_FILE):
        with open(DATA_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    return []

def save_todos(todos):
    """Save todos to JSON file"""
    with open(DATA_FILE, 'w', encoding='utf-8') as f:
        json.dump(todos, f, ensure_ascii=False, indent=2)

def get_next_id(todos):
    """Get next available ID"""
    if not todos:
        return 1
    return max(todo['id'] for todo in todos) + 1

# API Routes

@app.route('/api/todos', methods=['GET'])
def get_todos():
    """Get all todos"""
    try:
        todos = load_todos()
        return jsonify({
            'success': True,
            'data': todos,
            'count': len(todos)
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/todos', methods=['POST'])
def create_todo():
    """Create a new todo"""
    try:
        data = request.get_json()
        
        # Validation
        if not data or 'title' not in data:
            return jsonify({
                'success': False,
                'error': 'Title is required'
            }), 400
        
        todos = load_todos()
        
        # Create new todo
        new_todo = {
            'id': get_next_id(todos),
            'title': data['title'],
            'description': data.get('description', ''),
            'completed': False,
            'created_at': datetime.now().isoformat(),
            'updated_at': datetime.now().isoformat()
        }
        
        todos.append(new_todo)
        save_todos(todos)
        
        return jsonify({
            'success': True,
            'data': new_todo
        }), 201
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/todos/<int:todo_id>', methods=['PUT'])
def update_todo(todo_id):
    """Update a specific todo"""
    try:
        data = request.get_json()
        todos = load_todos()
        
        # Find todo
        todo = next((t for t in todos if t['id'] == todo_id), None)
        if not todo:
            return jsonify({
                'success': False,
                'error': 'Todo not found'
            }), 404
        
        # Update fields
        if 'title' in data:
            todo['title'] = data['title']
        if 'description' in data:
            todo['description'] = data['description']
        if 'completed' in data:
            todo['completed'] = bool(data['completed'])
        
        todo['updated_at'] = datetime.now().isoformat()
        
        save_todos(todos)
        
        return jsonify({
            'success': True,
            'data': todo
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/todos/<int:todo_id>', methods=['DELETE'])
def delete_todo(todo_id):
    """Delete a specific todo"""
    try:
        todos = load_todos()
        
        # Find and remove todo
        original_length = len(todos)
        todos = [t for t in todos if t['id'] != todo_id]
        
        if len(todos) == original_length:
            return jsonify({
                'success': False,
                'error': 'Todo not found'
            }), 404
        
        save_todos(todos)
        
        return jsonify({
            'success': True,
            'message': 'Todo deleted successfully'
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({
        'success': True,
        'message': 'Claude AI Backend is running!',
        'timestamp': datetime.now().isoformat(),
        'version': '1.0.0'
    })

@app.route('/', methods=['GET'])
def root():
    """Root endpoint with API information"""
    return jsonify({
        'message': 'Todo API by Claude AI',
        'description': 'AI Collaboration Demo Backend',
        'endpoints': {
            'GET /api/todos': 'Get all todos',
            'POST /api/todos': 'Create new todo',
            'PUT /api/todos/{id}': 'Update todo',
            'DELETE /api/todos/{id}': 'Delete todo',
            'GET /api/health': 'Health check'
        },
        'status': 'Ready for Gemini AI frontend integration! 🤖🤝🤖'
    })

if __name__ == '__main__':
    print("🤖 Claude AI Backend Server Starting...")
    print("🔗 Ready for collaboration with Gemini AI!")
    print("📡 Server running on http://localhost:5000")
    print("🔄 CORS enabled for frontend integration")
    
    # Create initial empty todos file if it doesn't exist
    if not os.path.exists(DATA_FILE):
        save_todos([])
        print("📁 Created empty todos database")
    
    app.run(debug=True, host='0.0.0.0', port=5000)
