# Todo Backend API (Claude's Module)

할 일 관리 시스템의 백엔드 API입니다.

## 기능

- **GET /api/todos**: 모든 할 일 목록 조회
- **POST /api/todos**: 새로운 할 일 추가
- **PUT /api/todos/{id}**: 특정 할 일 수정
- **DELETE /api/todos/{id}**: 특정 할 일 삭제

## 데이터 모델

```python
{
    "id": 1,
    "title": "할 일 제목",
    "description": "상세 설명",
    "completed": False,
    "created_at": "2025-06-16T23:45:00",
    "updated_at": "2025-06-16T23:45:00"
}
```

## 설치 및 실행

```bash
cd claude-modules
pip install flask
python app.py
```

서버는 http://localhost:5000 에서 실행됩니다.
