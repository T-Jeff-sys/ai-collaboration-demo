/**
 * 데이터 검증 유틸리티
 * Claude AI와 Gemini AI 공동 사용
 */

/**
 * 할 일 제목 검증
 * @param {string} title - 제목
 * @returns {object} 검증 결과 {isValid, message}
 */
function validateTitle(title) {
    if (!title || typeof title !== 'string') {
        return {
            isValid: false,
            message: '제목은 필수입니다.'
        };
    }
    
    if (title.trim().length === 0) {
        return {
            isValid: false,
            message: '제목은 공백일 수 없습니다.'
        };
    }
    
    if (title.length > 100) {
        return {
            isValid: false,
            message: '제목은 100자를 초과할 수 없습니다.'
        };
    }
    
    return {
        isValid: true,
        message: '유효한 제목입니다.'
    };
}

/**
 * 할 일 설명 검증
 * @param {string} description - 설명
 * @returns {object} 검증 결과
 */
function validateDescription(description) {
    if (description && typeof description !== 'string') {
        return {
            isValid: false,
            message: '설명은 문자열이어야 합니다.'
        };
    }
    
    if (description && description.length > 500) {
        return {
            isValid: false,
            message: '설명은 500자를 초과할 수 없습니다.'
        };
    }
    
    return {
        isValid: true,
        message: '유효한 설명입니다.'
    };
}

/**
 * 할 일 객체 전체 검증
 * @param {object} todo - 할 일 객체
 * @returns {object} 검증 결과
 */
function validateTodo(todo) {
    if (!todo || typeof todo !== 'object') {
        return {
            isValid: false,
            message: '유효하지 않은 할 일 객체입니다.'
        };
    }
    
    const titleValidation = validateTitle(todo.title);
    if (!titleValidation.isValid) {
        return titleValidation;
    }
    
    const descriptionValidation = validateDescription(todo.description);
    if (!descriptionValidation.isValid) {
        return descriptionValidation;
    }
    
    return {
        isValid: true,
        message: '유효한 할 일입니다.'
    };
}

/**
 * ID 검증
 * @param {*} id - ID 값
 * @returns {object} 검증 결과
 */
function validateId(id) {
    const numId = Number(id);
    
    if (isNaN(numId) || numId <= 0 || !Number.isInteger(numId)) {
        return {
            isValid: false,
            message: 'ID는 양의 정수여야 합니다.'
        };
    }
    
    return {
        isValid: true,
        message: '유효한 ID입니다.'
    };
}

/**
 * 완료 상태 검증
 * @param {*} completed - 완료 상태
 * @returns {object} 검증 결과
 */
function validateCompleted(completed) {
    if (completed !== undefined && typeof completed !== 'boolean') {
        return {
            isValid: false,
            message: '완료 상태는 boolean 값이어야 합니다.'
        };
    }
    
    return {
        isValid: true,
        message: '유효한 완료 상태입니다.'
    };
}

// 브라우저 환경에서 사용
if (typeof window !== 'undefined') {
    window.ValidationUtils = {
        validateTitle,
        validateDescription,
        validateTodo,
        validateId,
        validateCompleted
    };
}

// Node.js 환경에서 사용
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        validateTitle,
        validateDescription,
        validateTodo,
        validateId,
        validateCompleted
    };
}
