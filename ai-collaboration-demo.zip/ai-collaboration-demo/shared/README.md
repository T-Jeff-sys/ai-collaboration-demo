# 공통 유틸리티

Claude AI와 Gemini AI가 공동으로 사용할 수 있는 유틸리티 함수들입니다.

## 사용법

이 디렉토리의 파일들은 두 AI 모두 참조하고 활용할 수 있습니다.

### JavaScript 유틸리티 (프론트엔드용)

- `api-utils.js`: API 통신 공통 함수
- `validation.js`: 데이터 검증 함수
- `helpers.js`: 일반적인 헬퍼 함수

### Python 유틸리티 (백엔드용)

- `validators.py`: 데이터 검증 함수
- `helpers.py`: 일반적인 헬퍼 함수
- `constants.py`: 공통 상수들

## 규칙

1. 공통 함수는 이 디렉토리에 추가
2. 각 AI가 수정 시 상대방에게 영향 확인
3. 버전 관리를 통한 충돌 방지
