/**
 * API 통신 유틸리티 함수들
 * Claude AI와 Gemini AI 공동 사용
 */

// API 기본 설정
const API_CONFIG = {
    BASE_URL: 'http://localhost:5000/api',
    TIMEOUT: 5000,
    HEADERS: {
        'Content-Type': 'application/json'
    }
};

/**
 * 기본 API 요청 함수
 * @param {string} endpoint - API 엔드포인트
 * @param {object} options - fetch 옵션
 * @returns {Promise} API 응답
 */
async function apiRequest(endpoint, options = {}) {
    const url = `${API_CONFIG.BASE_URL}${endpoint}`;
    
    const defaultOptions = {
        headers: API_CONFIG.HEADERS,
        ...options
    };

    try {
        const response = await fetch(url, defaultOptions);
        const data = await response.json();
        
        if (!response.ok) {
            throw new Error(data.error || `HTTP ${response.status}`);
        }
        
        return data;
    } catch (error) {
        console.error('API 요청 실패:', error);
        throw error;
    }
}

/**
 * 모든 할 일 가져오기
 */
async function getAllTodos() {
    return await apiRequest('/todos');
}

/**
 * 새 할 일 생성
 * @param {object} todo - 할 일 객체 {title, description}
 */
async function createTodo(todo) {
    return await apiRequest('/todos', {
        method: 'POST',
        body: JSON.stringify(todo)
    });
}

/**
 * 할 일 수정
 * @param {number} id - 할 일 ID
 * @param {object} updates - 수정할 데이터
 */
async function updateTodo(id, updates) {
    return await apiRequest(`/todos/${id}`, {
        method: 'PUT',
        body: JSON.stringify(updates)
    });
}

/**
 * 할 일 삭제
 * @param {number} id - 할 일 ID
 */
async function deleteTodo(id) {
    return await apiRequest(`/todos/${id}`, {
        method: 'DELETE'
    });
}

/**
 * 서버 상태 확인
 */
async function checkHealth() {
    return await apiRequest('/health');
}

// 브라우저 환경에서 사용할 수 있도록 export
if (typeof window !== 'undefined') {
    window.ApiUtils = {
        getAllTodos,
        createTodo,
        updateTodo,
        deleteTodo,
        checkHealth,
        apiRequest,
        API_CONFIG
    };
}

// Node.js 환경에서 사용할 수 있도록 export
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        getAllTodos,
        createTodo,
        updateTodo,
        deleteTodo,
        checkHealth,
        apiRequest,
        API_CONFIG
    };
}
