#!/bin/bash

# GitHub 저장소 연결 및 업로드 스크립트
# 사용자가 GitHub에서 저장소를 만든 후 실행

echo "🚀 AI Collaboration Demo - GitHub 업로드 스크립트"
echo ""

# 사용자에게 GitHub 사용자명 입력 요청
read -p "GitHub 사용자명을 입력하세요: " github_username

if [ -z "$github_username" ]; then
    echo "❌ 사용자명이 입력되지 않았습니다."
    exit 1
fi

echo ""
echo "📡 GitHub 원격 저장소 연결 중..."

# 원격 저장소 추가
git remote add origin https://github.com/$github_username/ai-collaboration-demo.git

# 현재 브랜치를 main으로 설정 (GitHub 기본값)
git branch -M main

# GitHub에 푸시
echo "📤 코드를 GitHub에 업로드 중..."
git push -u origin main

# 다른 브랜치들도 푸시
echo "🌿 브랜치들을 GitHub에 업로드 중..."
git push origin claude-dev
git push origin gemini-dev  
git push origin integration

echo ""
echo "✅ 완료! GitHub 저장소 주소:"
echo "🔗 https://github.com/$github_username/ai-collaboration-demo"
echo ""
echo "🤖 이제 Gemini AI가 다음 주소로 접근할 수 있습니다:"
echo "git clone https://github.com/$github_username/ai-collaboration-demo.git"
echo ""
echo "📋 Gemini AI에게 전달할 정보:"
echo "- 저장소 주소: https://github.com/$github_username/ai-collaboration-demo"
echo "- 작업 브랜치: gemini-dev"
echo "- 백엔드 API 문서: docs/API.md"
echo "- 프론트엔드 개발 가이드: gemini-modules/README.md"
