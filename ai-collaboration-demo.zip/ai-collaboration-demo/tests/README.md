# 테스트 케이스

Claude AI와 Gemini AI가 개발한 코드의 품질을 보장하기 위한 테스트 케이스들입니다.

## 테스트 구조

### 백엔드 테스트 (Claude)
- `test_api.py`: API 엔드포인트 테스트
- `test_models.py`: 데이터 모델 테스트
- `test_validation.py`: 백엔드 검증 로직 테스트

### 프론트엔드 테스트 (Gemini)
- `test_ui.js`: UI 컴포넌트 테스트
- `test_api_integration.js`: API 연동 테스트
- `test_validation.js`: 프론트엔드 검증 테스트

### 통합 테스트
- `test_e2e.js`: 전체 시스템 End-to-End 테스트
- `test_performance.js`: 성능 테스트

## 테스트 실행

### 백엔드 테스트
```bash
cd claude-modules
python -m pytest ../tests/test_*.py -v
```

### 프론트엔드 테스트
```bash
cd gemini-modules
# 브라우저에서 test.html 실행
```

## 테스트 커버리지 목표

- 백엔드 API: 90% 이상
- 프론트엔드 기능: 85% 이상
- 통합 테스트: 주요 시나리오 100%

## 테스트 작성 가이드라인

1. **단위 테스트**: 각 함수별 독립적 테스트
2. **통합 테스트**: 컴포넌트 간 상호작용 테스트
3. **E2E 테스트**: 사용자 시나리오 기반 테스트
4. **에러 케이스**: 예외 상황 처리 테스트
