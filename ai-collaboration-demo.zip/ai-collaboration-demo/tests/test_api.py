"""
백엔드 API 테스트
Created by Claude AI

Flask API 엔드포인트들의 정확성을 테스트합니다.
"""

import pytest
import json
import os
import sys

# 프로젝트 루트를 Python 경로에 추가
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'claude-modules'))

from app import app

@pytest.fixture
def client():
    """테스트 클라이언트 설정"""
    app.config['TESTING'] = True
    with app.test_client() as client:
        # 테스트용 임시 데이터 파일 사용
        app.config['DATA_FILE'] = 'test_todos.json'
        yield client
        
        # 테스트 후 임시 파일 정리
        if os.path.exists('test_todos.json'):
            os.remove('test_todos.json')

def test_health_check(client):
    """헬스 체크 엔드포인트 테스트"""
    response = client.get('/api/health')
    assert response.status_code == 200
    
    data = json.loads(response.data)
    assert data['success'] is True
    assert 'Claude AI Backend is running!' in data['message']

def test_get_empty_todos(client):
    """빈 할 일 목록 조회 테스트"""
    response = client.get('/api/todos')
    assert response.status_code == 200
    
    data = json.loads(response.data)
    assert data['success'] is True
    assert data['data'] == []
    assert data['count'] == 0

def test_create_todo(client):
    """할 일 생성 테스트"""
    todo_data = {
        'title': '테스트 할 일',
        'description': '테스트 설명'
    }
    
    response = client.post('/api/todos', 
                          data=json.dumps(todo_data),
                          content_type='application/json')
    assert response.status_code == 201
    
    data = json.loads(response.data)
    assert data['success'] is True
    assert data['data']['title'] == '테스트 할 일'
    assert data['data']['description'] == '테스트 설명'
    assert data['data']['completed'] is False
    assert 'id' in data['data']
    assert 'created_at' in data['data']
    assert 'updated_at' in data['data']

def test_create_todo_without_title(client):
    """제목 없이 할 일 생성 시 에러 테스트"""
    todo_data = {
        'description': '설명만 있음'
    }
    
    response = client.post('/api/todos',
                          data=json.dumps(todo_data),
                          content_type='application/json')
    assert response.status_code == 400
    
    data = json.loads(response.data)
    assert data['success'] is False
    assert 'Title is required' in data['error']

def test_get_todos_after_creation(client):
    """할 일 생성 후 목록 조회 테스트"""
    # 할 일 생성
    todo_data = {'title': '테스트 할 일'}
    client.post('/api/todos',
               data=json.dumps(todo_data),
               content_type='application/json')
    
    # 목록 조회
    response = client.get('/api/todos')
    assert response.status_code == 200
    
    data = json.loads(response.data)
    assert data['success'] is True
    assert len(data['data']) == 1
    assert data['count'] == 1

def test_update_todo(client):
    """할 일 수정 테스트"""
    # 할 일 생성
    todo_data = {'title': '원본 제목'}
    create_response = client.post('/api/todos',
                                 data=json.dumps(todo_data),
                                 content_type='application/json')
    created_todo = json.loads(create_response.data)['data']
    todo_id = created_todo['id']
    
    # 할 일 수정
    update_data = {
        'title': '수정된 제목',
        'completed': True
    }
    response = client.put(f'/api/todos/{todo_id}',
                         data=json.dumps(update_data),
                         content_type='application/json')
    assert response.status_code == 200
    
    data = json.loads(response.data)
    assert data['success'] is True
    assert data['data']['title'] == '수정된 제목'
    assert data['data']['completed'] is True

def test_update_nonexistent_todo(client):
    """존재하지 않는 할 일 수정 시 에러 테스트"""
    update_data = {'title': '수정'}
    response = client.put('/api/todos/999',
                         data=json.dumps(update_data),
                         content_type='application/json')
    assert response.status_code == 404
    
    data = json.loads(response.data)
    assert data['success'] is False
    assert 'Todo not found' in data['error']

def test_delete_todo(client):
    """할 일 삭제 테스트"""
    # 할 일 생성
    todo_data = {'title': '삭제될 할 일'}
    create_response = client.post('/api/todos',
                                 data=json.dumps(todo_data),
                                 content_type='application/json')
    created_todo = json.loads(create_response.data)['data']
    todo_id = created_todo['id']
    
    # 할 일 삭제
    response = client.delete(f'/api/todos/{todo_id}')
    assert response.status_code == 200
    
    data = json.loads(response.data)
    assert data['success'] is True
    assert 'deleted successfully' in data['message']
    
    # 삭제 확인
    get_response = client.get('/api/todos')
    get_data = json.loads(get_response.data)
    assert get_data['count'] == 0

def test_delete_nonexistent_todo(client):
    """존재하지 않는 할 일 삭제 시 에러 테스트"""
    response = client.delete('/api/todos/999')
    assert response.status_code == 404
    
    data = json.loads(response.data)
    assert data['success'] is False
    assert 'Todo not found' in data['error']

def test_root_endpoint(client):
    """루트 엔드포인트 테스트"""
    response = client.get('/')
    assert response.status_code == 200
    
    data = json.loads(response.data)
    assert 'Todo API by Claude AI' in data['message']
    assert 'endpoints' in data

if __name__ == '__main__':
    pytest.main([__file__, '-v'])
